# 💫 About Me:
### ⚡ AI/ML + Quant | Building high-performance systems for real-world problems<br><br>🔭 I’m currently working on  <br>- Quant research: alpha generation & backtesting frameworks  <br>- High-performance systems in python (inventory optimization & DS-driven design)  <br>- AI-driven cloud security: IAM policy analysis & simulation  <br><br>👯 I’m looking to collaborate on  <br>- Open source projects (GSoC-focused orgs)  <br>- Quant finance / algorithmic trading systems  <br>- Low-latency, performance-critical systems  <br><br>🤝 I’m looking for help with  <br>- Advanced time series modeling & quantitative strategies  <br>- Designing low-latency systems (HFT-oriented)  <br>- Contributing to large-scale production-grade codebases  <br><br>🌱 I’m currently exploring.<br>- Probability, statistics & stochastic processes  <br>- Advanced DSA & system design  <br>- Machine learning for financial data  <br><br>💬 Ask me about  <br>- Data Structures & Algorithms  <br>- Quant basics & WorldQuant BRAIN  <br>- System-level thinking in real-world projects  <br><br>⚡ Fun fact  <br>- Focused on building toward high-frequency trading systems 🚀  


## 🌐 Socials:
[![Discord](https://img.shields.io/badge/Discord-%237289DA.svg?logo=discord&logoColor=white)](https://discord.gg/hB436VQa) [![Instagram](https://img.shields.io/badge/Instagram-%23E4405F.svg?logo=Instagram&logoColor=white)](https://instagram.com/saatwik_yadav) [![LinkedIn](https://img.shields.io/badge/LinkedIn-%230077B5.svg?logo=linkedin&logoColor=white)](https://www.linkedin.com/in/saatwik-kumar-yadav-523536337/) [![email](https://img.shields.io/badge/Email-D14836?logo=gmail&logoColor=white)](mailto:saatwik.dav@gmail.com ) 

# 🏅 GSSoC 2026 Badges:

<p align="center">
  <img src="./assets/gssoc/elite.png" alt="GSSoC 2026 Elite" width="140" title="Elite" />
  <img src="./assets/gssoc/power-contributor.png" alt="GSSoC 2026 Power Contributor" width="140" title="Power Contributor" />
  <img src="./assets/gssoc/rising-star.png" alt="GSSoC 2026 Rising Star" width="140" title="Rising Star" />
  <img src="./assets/gssoc/point-scorer.png" alt="GSSoC 2026 Point Scorer" width="140" title="Point Scorer" />
  <img src="./assets/gssoc/rare-merged.png" alt="GSSoC 2026 Rare Merged" width="140" title="Rare Merged" />
</p>

<p align="center">
  <img src="./assets/gssoc/5-pr-merge.png" alt="GSSoC 2026 5 PR Merge" width="105" title="5 PR Merge" />
  <img src="./assets/gssoc/bounty-hunter.png" alt="GSSoC 2026 Bounty Hunter" width="105" title="Bounty Hunter" />
  <img src="./assets/gssoc/building-momentum.png" alt="GSSoC 2026 Building Momentum" width="105" title="Building Momentum" />
  <img src="./assets/gssoc/contributor.png" alt="GSSoC 2026 Contributor" width="105" title="Contributor" />
  <img src="./assets/gssoc/first-step.png" alt="GSSoC 2026 First Step" width="105" title="First Step" />
  <img src="./assets/gssoc/profile-complete.png" alt="GSSoC 2026 Profile Complete" width="105" title="Profile Complete" />
  <img src="./assets/gssoc/discord-verified.png" alt="GSSoC 2026 Discord Verified" width="105" title="Discord Verified" />
</p>

# 💻 Tech Stack:
![C](https://img.shields.io/badge/c-%2300599C.svg?style=for-the-badge&logo=c&logoColor=white) ![C++](https://img.shields.io/badge/c++-%2300599C.svg?style=for-the-badge&logo=c%2B%2B&logoColor=white) ![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white) ![JavaScript](https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E) ![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white) ![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54) ![TypeScript](https://img.shields.io/badge/typescript-%23007ACC.svg?style=for-the-badge&logo=typescript&logoColor=white) ![Windows Terminal](https://img.shields.io/badge/Windows%20Terminal-%234D4D4D.svg?style=for-the-badge&logo=windows-terminal&logoColor=white) ![PowerShell](https://img.shields.io/badge/PowerShell-%235391FE.svg?style=for-the-badge&logo=powershell&logoColor=white) ![Google Cloud](https://img.shields.io/badge/GoogleCloud-%234285F4.svg?style=for-the-badge&logo=google-cloud&logoColor=white) ![Vercel](https://img.shields.io/badge/vercel-%23000000.svg?style=for-the-badge&logo=vercel&logoColor=white) ![Firebase](https://img.shields.io/badge/firebase-%23039BE5.svg?style=for-the-badge&logo=firebase) ![Render](https://img.shields.io/badge/Render-%46E3B7.svg?style=for-the-badge&logo=render&logoColor=white) ![FastAPI](https://img.shields.io/badge/FastAPI-005571?style=for-the-badge&logo=fastapi) ![Flask](https://img.shields.io/badge/flask-%23000.svg?style=for-the-badge&logo=flask&logoColor=white) ![MySQL](https://img.shields.io/badge/mysql-4479A1.svg?style=for-the-badge&logo=mysql&logoColor=white) ![Figma](https://img.shields.io/badge/figma-%23F24E1E.svg?style=for-the-badge&logo=figma&logoColor=white) ![Canva](https://img.shields.io/badge/Canva-%2300C4CC.svg?style=for-the-badge&logo=Canva&logoColor=white) ![NumPy](https://img.shields.io/badge/numpy-%23013243.svg?style=for-the-badge&logo=numpy&logoColor=white) ![Pandas](https://img.shields.io/badge/pandas-%23150458.svg?style=for-the-badge&logo=pandas&logoColor=white) ![PyTorch](https://img.shields.io/badge/PyTorch-%23EE4C2C.svg?style=for-the-badge&logo=PyTorch&logoColor=white) ![scikit-learn](https://img.shields.io/badge/scikit--learn-%23F7931E.svg?style=for-the-badge&logo=scikit-learn&logoColor=white) ![Plotly](https://img.shields.io/badge/Plotly-%233F4F75.svg?style=for-the-badge&logo=plotly&logoColor=white) ![TensorFlow](https://img.shields.io/badge/TensorFlow-%23FF6F00.svg?style=for-the-badge&logo=TensorFlow&logoColor=white) ![Git](https://img.shields.io/badge/git-%23F05033.svg?style=for-the-badge&logo=git&logoColor=white) ![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white) ![Playwright](https://img.shields.io/badge/-playwright-%232EAD33?style=for-the-badge&logo=playwright&logoColor=white) ![Docker](https://img.shields.io/badge/docker-%230db7ed.svg?style=for-the-badge&logo=docker&logoColor=white)
# 📊 GitHub Stats:
![](https://github-readme-stats.shion.dev/api?username=skypank-coder&theme=github_dark_dimmed&hide_border=false&include_all_commits=false&count_private=false)<br/>
![](https://streak-stats.demolab.com/?user=skypank-coder&theme=github_dark_dimmed&hide_border=false)<br/>
![](https://github-readme-stats.shion.dev/api/top-langs/?username=skypank-coder&theme=github_dark_dimmed&hide_border=false&include_all_commits=false&count_private=false&layout=compact)



### ✍️ Random Dev Quote
![](https://quotes-github-readme.vercel.app/api?type=horizontal&theme=dark)

---
[![](https://komarev.com/ghpvc/?username=skypank-coder&icon=0&color=0)](https://visitcount.itsvg.in)

  ## 💰 You can help me by Donating
  [![PayPal](https://img.shields.io/badge/PayPal-00457C?style=for-the-badge&logo=paypal&logoColor=white)](https://paypal.me/@SaatwikYadav) 

  
<!-- Proudly created with GPRM ( https://gprm.itsvg.in ) -->
